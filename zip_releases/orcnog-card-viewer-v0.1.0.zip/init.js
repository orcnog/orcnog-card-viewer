/**
 * @module init
 */
import registerHooks from "./module/hooks.mjs";

/**
 * Register all hooks from the hooks module
 */
registerHooks();